import { NextResponse } from 'next/server';
import { createServerClient } from '@supabase/ssr';

const url = process.env.NEXT_PUBLIC_SUPABASE_URL;
const anonKey = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY;
const configured = Boolean(url && anonKey && !url.includes('your-project') && !anonKey.includes('your-anon-key'));

export async function middleware(request) {
  const response = NextResponse.next();
  const { pathname } = request.nextUrl;
  const protectingAdmin = pathname.startsWith('/admin');
  const protectingProfile = pathname.startsWith('/profile');

  // Supabase not configured (local/dev): don't block routes, just pass through.
  if (!configured || (!protectingAdmin && !protectingProfile)) {
    return response;
  }

  const supabase = createServerClient(url, anonKey, {
    cookies: {
      get(name) {
        return request.cookies.get(name)?.value;
      },
      set(name, value, options) {
        response.cookies.set({ name, value, ...options });
      },
      remove(name, options) {
        response.cookies.set({ name, value: '', ...options });
      }
    }
  });

  const { data: { user } } = await supabase.auth.getUser();

  if (!user) {
    const loginUrl = new URL('/login', request.url);
    return NextResponse.redirect(loginUrl);
  }

  if (protectingAdmin) {
    const { data: profile } = await supabase.from('users').select('role').eq('id', user.id).maybeSingle();
    if (!profile || profile.role !== 'admin') {
      const loginUrl = new URL('/login', request.url);
      return NextResponse.redirect(loginUrl);
    }
  }

  return response;
}

export const config = {
  matcher: ['/admin/:path*', '/profile/:path*']
};
