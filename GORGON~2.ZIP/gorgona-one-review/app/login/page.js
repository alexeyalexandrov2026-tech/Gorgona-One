"use client";

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import { supabase, supabaseConfigured } from '../../lib/supabaseClient';

export default function LoginPage() {
  const router = useRouter();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [status, setStatus] = useState({ type: 'idle', message: '' });

  const handleSubmit = async (event) => {
    event.preventDefault();
    if (!supabaseConfigured) {
      setStatus({ type: 'error', message: 'Supabase is not configured for this environment.' });
      return;
    }
    setStatus({ type: 'loading', message: '' });
    const { error } = await supabase.auth.signInWithPassword({ email, password });
    if (error) {
      setStatus({ type: 'error', message: error.message });
      return;
    }
    setStatus({ type: 'success', message: 'Signed in — redirecting…' });
    router.push('/profile');
    router.refresh();
  };

  return (
    <