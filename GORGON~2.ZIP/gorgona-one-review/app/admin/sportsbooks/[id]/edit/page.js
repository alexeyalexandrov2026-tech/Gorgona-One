import { notFound } from 'next/navigation';
import { requireAdmin } from '../../../../../lib/adminAuth';
import { getSportsbooks } from '../../../../../lib/mockData';
import { updateSportsbook } from '../../../actions';

export default async function EditSportsbookPage({ params }) {
  await requireAdmin();
  const sportsbooks = await getSportsbooks();
  const book = sportsbooks.find((entry) => String(entry.id) === params.id);
  if (!book) notFound();

  return (
    <main className="flex-1 py-10">
      <div className="rounded-2xl border border-white/10 bg-black/40 p-6">
        <h1 className="text-lg font-semibold text-white">Edit sportsbook: {book.name}</h1>
        <form action={updateSportsbook} className="mt-4 grid gap-3 md:grid-cols-2">
          <input type="hidden" name="id" value={book.id} />
          <input name="name" defaultValue={book.name} required placeholder="Name" className="rounded-xl border border-white/10 bg-black/50 px-3 py-2 text-white outline-none" />
          <input name="slug" defaultValue={book.slug} required placeholder="Slug" className="rounded-xl border border-white/10 bg-black/50 px-3 py-2 text-white outline-none" />
          <input name="logo" defaultValue={book.logo} placeholder="Logo initials/URL" className="rounded-xl border border-white/10 bg-black/50 px-3 py-2 text-white outline-none" />
          <input name="website" defaultValue={book.website} placeholder="Website" className="rounded-xl border border-white/10 bg-black/50 px-3 py-2 text-white outline-none" />
          <input name="affiliate_link" defaultValue={book.affiliate_link} placeholder="Affiliate link" className="rounded-xl border border-white/10 bg-black/50 px-3 py-2 text-white outline-none" />
          <input name="promo_code" defaultValue={book.promo_code} placeholder="Promo code" className="rounded-xl border border-white/10 bg-black/50 px-3 py-2 text-white outline-none" />
          <input name="bonus_offer" defaultValue={book.bonus_offer} placeholder="Bonus offer" className="rounded-xl border border-white/10 bg-black/50 px-3 py-2 text-white outline-none" />
          <input name="state_availability" defaultValue={book.state_availability} placeholder="State availability" className="rounded-xl border border-white/10 bg-black/50 px-3 py-2 text-white outline-none" />
          <textarea name="description" defaultValue={book.description} placeholder="Description" className="md:col-span-2 rounded-xl border border-white/10 bg-black/50 px-3 py-2 text-white outline-none" />
          <select name="status" defaultValue={book.status} className="rounded-xl border border-white/10 bg-black/50 px-3 py-2 text-white outline-none">
            <option value="active">active</option>
            <option value="inactive">inactive</option>
          </select>
          <button type="submit" className="md:col-span-2 rounded-full bg-brand-gold px-4 py-2 font-medium text-black">Save changes</button>
        </form>
      </div>
    </main>
  );
}
