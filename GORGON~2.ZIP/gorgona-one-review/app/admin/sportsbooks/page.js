import Link from 'next/link';
import { requireAdmin } from '../../../lib/adminAuth';
import { getSportsbooks } from '../../../lib/mockData';
import { createSportsbook, deleteSportsbook } from '../actions';

export default async function AdminSportsbooksPage() {
  await requireAdmin();
  const sportsbooks = await getSportsbooks();

  return (
    <main className="flex-1 py-10">
      <div className="rounded-3xl border border-brand-gold/20 bg-brand-gold/10 p-8 shadow-premium">
        <p className="text-sm uppercase tracking-[0.3em] text-brand-gold">Admin</p>
        <h1 className="mt-2 text-3xl font-semibold text-white">Manage sportsbooks</h1>
        <Link href="/admin" className="mt-4 inline-flex text-sm text-brand-gold">Back to dashboard</Link>
      </div>

      <div className="mt-8 rounded-2xl border border-white/10 bg-black/40 p-6">
        <h2 className="text-lg font-semibold text-white">Add a sportsbook</h2>
        <form action={createSportsbook} className="mt-4 grid gap-3 md:grid-cols-2">
          <input name="name" required placeholder="Name" className="rounded-xl border border-white/10 bg-black/50 px-3 py-2 text-white outline-none" />
          <input name="slug" required placeholder="Slug" className="rounded-xl border border-white/10 bg-black/50 px-3 py-2 text-white outline-none" />
          <input name="logo" placeholder="Logo initials/URL" className="rounded-xl border border-white/10 bg-black/50 px-3 py-2 text-white outline-none" />
          <input name="website" placeholder="Website" className="rounded-xl border border-white/10 bg-black/50 px-3 py-2 text-white outline-none" />
          <input name="affiliate_link" placeholder="Affiliate link" className="rounded-xl border border-white/10 bg-black/50 px-3 py-2 text-white outline-none" />
          <input name="promo_code" placeholder="Promo code" className="rounded-xl border border-white/10 bg-black/50 px-3 py-2 text-white outline-none" />
          <input name="bonus_offer" placeholder="Bonus offer" className="rounded-xl border border-white/10 bg-black/50 px-3 py-2 text-white outline-none" />
          <input name="state_availability" placeholder="State availability" className="rounded-xl border border-white/10 bg-black/50 px-3 py-2 text-white outline-none" />
          <textarea name="description" placeholder="Description" className="md:col-span-2 rounded-xl border border-white/10 bg-black/50 px-3 py-2 text-white outline-none" />
          <select name="status" className="rounded-xl border border-white/10 bg-black/50 px-3 py-2 text-white outline-none">
            <option value="active">active</option>
            <option value="inactive">inactive</option>
          </select>
          <button type="submit" className="md:col-span-2 rounded-full bg-brand-gold px-4 py-2 font-medium text-black">Create sportsbook</button>
        </form>
      </div>

      <div className="mt-8 space-y-3">
        {sportsbooks.map((book) => (
          <div key={book.id} className="flex flex-wrap items-center justify-between gap-3 rounded-2xl border border-white/10 bg-black/40 p-4">
            <div>
              <p className="font-semibold text-white">{book.name} <span className="text-xs text-zinc-500">({book.slug})</span></p>
              <p className="text-sm text-zinc-400">{book.status} · {book.state_availability}</p>
            </div>
            <div className="flex items-center gap-3">
              <Link href={`/admin/sportsbooks/${book.id}/edit`} className="rounded-full border border-brand-gold/40 px-3 py-1 text-sm text-brand-gold">Edit</Link>
              <form action={deleteSportsbook}>
                <input type="hidden" name="id" value={book.id} />
                <button type="submit" className="rounded-full border border-red-400/40 px-3 py-1 text-sm text-red-400">Delete</button>
              </form>
            </div>
          </div>
        ))}
      </div>
    </main>
  );
}
