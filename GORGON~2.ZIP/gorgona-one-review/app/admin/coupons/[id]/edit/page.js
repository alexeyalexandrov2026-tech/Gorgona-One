import { notFound } from 'next/navigation';
import { requireAdmin } from '../../../../../lib/adminAuth';
import { getCoupons, getStores } from '../../../../../lib/mockData';
import { updateCoupon } from '../../../actions';

export default async function EditCouponPage({ params }) {
  await requireAdmin();
  const [coupons, stores] = await Promise.all([getCoupons(), getStores()]);
  const coupon = coupons.find((entry) => String(entry.id) === params.id);
  if (!coupon) notFound();

  return (
    <main className="flex-1 py-10">
      <div className="rounded-2xl border border-white/10 bg-black/40 p-6">
        <h1 className="text-lg font-semibold text-white">Edit coupon #{coupon.id}</h1>
        <form action={updateCoupon} className="mt-4 grid gap-3 md:grid-cols-2">
          <input type="hidden" name="id" value={coupon.id} />
          <select name="store_id" defaultValue={coupon.store_id} required className="rounded-xl border border-white/10 bg-black/50 px-3 py-2 text-white outline-none">
            {stores.map((store) => (
              <option key={store.id} value={store.id}>{store.name}</option>
            ))}
          </select>
          <input name="code" defaultValue={coupon.code} placeholder="Code" className="rounded-xl border border-white/10 bg-black/50 px-3 py-2 text-white outline-none" />
          <input name="discount" defaultValue={coupon.discount} required placeholder="Discount" className="rounded-xl border border-white/10 bg-black/50 px-3 py-2 text-white outline-none" />
          <input name="expiration" type="date" defaultValue={coupon.expiration} className="rounded-xl border border-white/10 bg-black/50 px-3 py-2 text-white outline-none" />
          <textarea name="description" defaultValue={coupon.description} placeholder="Description" className="md:col-span-2 rounded-xl border border-white/10 bg-black/50 px-3 py-2 text-white outline-none" />
          <select name="status" defaultValue={coupon.status} className="rounded-xl border border-white/10 bg-black/50 px-3 py-2 text-white outline-none">
            <option value="verified">verified</option>
            <option value="pending">pending</option>
            <option value="expired">expired</option>
          </select>
          <input name="clicks" type="number" defaultValue={coupon.clicks} placeholder="Clicks" className="rounded-xl border border-white/10 bg-black/50 px-3 py-2 text-white outline-none" />
          <button type="submit" className="md:col-span-2 rounded-full bg-brand-gold px-4 py-2 font-medium text-black">Save changes</button>
        </form>
      </div>
    </main>
  );
}
