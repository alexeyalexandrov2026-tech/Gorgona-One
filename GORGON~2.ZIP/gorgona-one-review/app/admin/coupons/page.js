import Link from 'next/link';
import { requireAdmin } from '../../../lib/adminAuth';
import { getCoupons, getStores } from '../../../lib/mockData';
import { createCoupon, deleteCoupon } from '../actions';

export default async function AdminCouponsPage() {
  await requireAdmin();
  const [coupons, stores] = await Promise.all([getCoupons(), getStores()]);

  return (
    <main className="flex-1 py-10">
      <div className="rounded-3xl border border-brand-gold/20 bg-brand-gold/10 p-8 shadow-premium">
        <p className="text-sm uppercase tracking-[0.3em] text-brand-gold">Admin</p>
        <h1 className="mt-2 text-3xl font-semibold text-white">Manage coupons</h1>
        <Link href="/admin" className="mt-4 inline-flex text-sm text-brand-gold">Back to dashboard</Link>
      </div>

      <div className="mt-8 rounded-2xl border border-white/10 bg-black/40 p-6">
        <h2 className="text-lg font-semibold text-white">Add a coupon</h2>
        <form action={createCoupon} className="mt-4 grid gap-3 md:grid-cols-2">
          <select name="store_id" required className="rounded-xl border border-white/10 bg-black/50 px-3 py-2 text-white outline-none">
            <option value="">Select store</option>
            {stores.map((store) => (
              <option key={store.id} value={store.id}>{store.name}</option>
            ))}
          </select>
          <input name="code" placeholder="Code" className="rounded-xl border border-white/10 bg-black/50 px-3 py-2 text-white outline-none" />
          <input name="discount" required placeholder="Discount" className="rounded-xl border border-white/10 bg-black/50 px-3 py-2 text-white outline-none" />
          <input name="expiration" type="date" className="rounded-xl border border-white/10 bg-black/50 px-3 py-2 text-white outline-none" />
          <textarea name="description" placeholder="Description" className="md:col-span-2 rounded-xl border border-white/10 bg-black/50 px-3 py-2 text-white outline-none" />
          <select name="status" className="rounded-xl border border-white/10 bg-black/50 px-3 py-2 text-white outline-none">
            <option value="verified">verified</option>
            <option value="pending">pending</option>
            <option value="expired">expired</option>
          </select>
          <input name="clicks" type="number" defaultValue={0} placeholder="Clicks" className="rounded-xl border border-white/10 bg-black/50 px-3 py-2 text-white outline-none" />
          <button type="submit" className="md:col-span-2 rounded-full bg-brand-gold px-4 py-2 font-medium text-black">Create coupon</button>
        </form>
      </div>

      <div className="mt-8 space-y-3">
        {coupons.map((coupon) => (
          <div key={coupon.id} className="flex flex-wrap items-center justify-between gap-3 rounded-2xl border border-white/10 bg-black/40 p-4">
            <div>
              <p className="font-semibold text-white">{coupon.store_name || coupon.store_id} — {coupon.discount}</p>
              <p className="text-sm text-zinc-400">{coupon.code || 'no code'} · {coupon.status} · {coupon.clicks} clicks</p>
            </div>
            <div className="flex items-center gap-3">
              <Link href={`/admin/coupons/${coupon.id}/edit`} className="rounded-full border border-brand-gold/40 px-3 py-1 text-sm text-brand-gold">Edit</Link>
              <form action={deleteCoupon}>
                <input type="hidden" name="id" value={coupon.id} />
                <button type="submit" className="rounded-full border border-red-400/40 px-3 py-1 text-sm text-red-400">Delete</button>
              </form>
            </div>
          </div>
        ))}
      </div>
    </main>
  );
}
