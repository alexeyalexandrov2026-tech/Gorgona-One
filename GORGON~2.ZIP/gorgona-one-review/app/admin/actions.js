'use server';

import { revalidatePath } from 'next/cache';
import { redirect } from 'next/navigation';
import { supabaseAdmin, supabaseAdminConfigured } from '../../lib/supabaseAdmin';
import { requireAdmin } from '../../lib/adminAuth';

function ensureReady() {
  if (!supabaseAdminConfigured) {
    throw new Error('Supabase service role is not configured.');
  }
}

// --- Stores ---

export async function createStore(formData) {
  await requireAdmin();
  ensureReady();
  await supabaseAdmin.from('stores').insert({
    name: formData.get('name'),
    slug: formData.get('slug'),
    category: formData.get('category'),
    logo: formData.get('logo'),
    website: formData.get('website'),
    affiliate_link: formData.get('affiliate_link'),
    description: formData.get('description'),
    featured: formData.get('featured') === 'on',
    status: formData.get('status') || 'active'
  });
  revalidatePath('/admin/stores');
  revalidatePath('/stores');
  revalidatePath('/coupons');
  redirect('/admin/stores');
}

export async function updateStore(formData) {
  await requireAdmin();
  ensureReady();
  const id = formData.get('id');
  await supabaseAdmin.from('stores').update({
    name: formData.get('name'),
    slug: formData.get('slug'),
    category: formData.get('category'),
    logo: formData.get('logo'),
    website: formData.get('website'),
    affiliate_link: formData.get('affiliate_link'),
    description: formData.get('description'),
    featured: formData.get('featured') === 'on',
    status: formData.get('status') || 'active'
  }).eq('id', id);
  revalidatePath('/admin/stores');
  revalidatePath('/stores');
  revalidatePath('/coupons');
  redirect('/admin/stores');
}

export async function deleteStore(formData) {
  await requireAdmin();
  ensureReady();
  const id = formData.get('id');
  await supabaseAdmin.from('stores').delete().eq('id', id);
  revalidatePath('/admin/stores');
  revalidatePath('/stores');
  revalidatePath('/coupons');
}

// --- Coupons ---

export async function createCoupon(formData) {
  await requireAdmin();
  ensureReady();
  await supabaseAdmin.from('coupons').insert({
    store_id: Number(formData.get('store_id')) || null,
    code: formData.get('code'),
    discount: formData.get('discount'),
    description: formData.get('description'),
    expiration: formData.get('expiration') || null,
    status: formData.get('status') || 'verified',
    clicks: Number(formData.get('clicks')) || 0
  });
  revalidatePath('/admin/coupons');
  revalidatePath('/coupons');
  revalidatePath('/stores');
  redirect('/admin/coupons');
}

export async function updateCoupon(formData) {
  await requireAdmin();
  ensureReady();
  const id = formData.get('id');
  await supabaseAdmin.from('coupons').update({
    store_id: Number(formData.get('store_id')) || null,
    code: formData.get('code'),
    discount: formData.get('discount'),
    description: formData.get('description'),
    expiration: formData.get('expiration') || null,
    status: formData.get('status') || 'verified',
    clicks: Number(formData.get('clicks')) || 0
  }).eq('id', id);
  revalidatePath('/admin/coupons');
  revalidatePath('/coupons');
  revalidatePath('/stores');
  redirect('/admin/coupons');
}

export async function deleteCoupon(formData) {
  await requireAdmin();
  ensureReady();
  const id = formData.get('id');
  await supabaseAdmin.from('coupons').delete().eq('id', id);
  revalidatePath('/admin/coupons');
  revalidatePath('/coupons');
  revalidatePath('/stores');
}

// --- Sportsbooks ---

export async function createSportsbook(formData) {
  await requireAdmin();
  ensureReady();
  await supabaseAdmin.from('sportsbooks').insert({
    name: formData.get('name'),
    slug: formData.get('slug'),
    logo: formData.get('logo'),
    description: formData.get('description'),
    website: formData.get('website'),
    affiliate_link: formData.get('affiliate_link'),
    promo_code: formData.get('promo_code'),
    bonus_offer: formData.get('bonus_offer'),
    state_availability: formData.get('state_availability'),
    status: formData.get('status') || 'active'
  });
  revalidatePath('/admin/sportsbooks');
  revalidatePath('/sportsbook');
  redirect('/admin/sportsbooks');
}

export async function updateSportsbook(formData) {
  await requireAdmin();
  ensureReady();
  const id = formData.get('id');
  await supabaseAdmin.from('sportsbooks').update({
    name: formData.get('name'),
    slug: formData.get('slug'),
    logo: formData.get('logo'),
    description: formData.get('description'),
    website: formData.get('website'),
    affiliate_link: formData.get('affiliate_link'),
    promo_code: formData.get('promo_code'),
    bonus_offer: formData.get('bonus_offer'),
    state_availability: formData.get('state_availability'),
    status: formData.get('status') || 'active'
  }).eq('id', id);
  revalidatePath('/admin/sportsbooks');
  revalidatePath('/sportsbook');
  redirect('/admin/sportsbooks');
}

export async function deleteSportsbook(formData) {
  await requireAdmin();
  ensureReady();
  const id = formData.get('id');
  await supabaseAdmin.from('sportsbooks').delete().eq('id', id);
  revalidatePath('/admin/sportsbooks');
  revalidatePath('/sportsbook');
}

// --- Partner submissions ---

export async function updatePartnerStatus(formData) {
  await requireAdmin();
  ensureReady();
  const id = formData.get('id');
  const status = formData.get('status');
  await supabaseAdmin.from('partner_submissions').update({ status }).eq('id', id);
  revalidatePath('/admin/partners');
}
