import Link from 'next/link';
import { requireAdmin } from '../../lib/adminAuth';

export default async function AdminPage() {
  await requireAdmin();

  return (
    <main className="flex-1 py-10">
      <div className="rounded-3xl border border-brand-gold/20 bg-brand-gold/10 p-8 shadow-premium">
        <p className="text-sm uppercase tracking-[0.3em] text-brand-gold">Protected Admin Dashboard</p>
        <h1 className="mt-2 text-3xl font-semibold text-white">Manage stores, coupons, sportsbook offers, and analytics</h1>
        <div className="mt-8 grid gap-4 md:grid-cols-2 xl:grid-cols-4">
          {[
            { label: 'Add stores', href: '/admin/stores' },
            { label: 'Edit coupons', href: '/admin/coupons' },
            { label: 'Delete offers', href: '/admin/coupons' },
            { la