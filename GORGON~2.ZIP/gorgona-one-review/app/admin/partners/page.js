import Link from 'next/link';
import { requireAdmin } from '../../../lib/adminAuth';
import { supabaseAdmin, supabaseAdminConfigured } from '../../../lib/supabaseAdmin';
import { updatePartnerStatus } from '../actions';

export default async function AdminPartnersPage() {
  await requireAdmin();

  let submissions = [];
  if (supabaseAdminConfigured) {
    const { data } = await supabaseAdmin.from('partner_submissions').select('*').order('created_at', { ascending: false });
    submissions = data || [];
  }

  return (
    <main className="flex-1 py-10">
      <div className="rounded-3xl border border-brand-gold/20 bg-brand-gold/10 p-8 shadow-premium">
        <p className="text-sm uppercase tracking-[0.3em] text-brand-gold">Admin</p>
        <h1 className="mt-2 text-3xl font-semibold text-white">Partner submissions</h1>
        <Link href="/admin" className="mt-4 inline-flex text-sm text-brand-gold">Back to dashboard</Link>
      </div>

      <div className="mt-8 space-y-3">
        {submissions.length === 0 ? <p className="text-sm text-zinc-400">No submissions yet.</p> : null}
        {submissions.map((entry) => (
          <div key={entry.id} className="flex flex-wrap items-center justify-between gap-3 rounded-2xl border border-white/10 bg-black/40 p-4">
            <div>
              <p className="font-semibold text-white">{entry.business_name}</p>
              <p className="text-sm text-zinc-400">{entry.email} · {entry.website} · {entry.status}</p>
            </div>
            <div className="flex items-center gap-2">
              <form action={updatePartnerStatus}>
                <input type="hidden" name="id" value={entry.id} />
                <input type="hidden" name="status" value="approved" />
                <button type="submit" className="rounded-full border border-brand-gold/40 px-3 py-1 text-sm text-brand-gold">Approve</button>
              </form>
              <form action={updatePartnerStatus}>
                <input type="hidden" name="id" value={entry.id} />
                <input type="hidden" name="status" value="rejected" />
                <button type="submit" className="rounded-full border border-red-400/40 px-3 py-1 text-sm text-red-400">Reject</button>
              </form>
            </div>
          </div>
        ))}
      </div>
    </main>
  );
}
