import { notFound } from 'next/navigation';
import { requireAdmin } from '../../../../../lib/adminAuth';
import { getStores } from '../../../../../lib/mockData';
import { updateStore } from '../../../actions';

export default async function EditStorePage({ params }) {
  await requireAdmin();
  const stores = await getStores();
  const store = stores.find((entry) => String(entry.id) === params.id);
  if (!store) notFound();

  return (
    <main className="flex-1 py-10">
      <div className="rounded-2xl border border-white/10 bg-black/40 p-6">
        <h1 className="text-lg font-semibold text-white">Edit store: {store.name}</h1>
        <form action={updateStore} className="mt-4 grid gap-3 md:grid-cols-2">
          <input type="hidden" name="id" value={store.id} />
          <input name="name" defaultValue={store.name} required placeholder="Name" className="rounded-xl border border-white/10 bg-black/50 px-3 py-2 text-white outline-none" />
          <input name="slug" defaultValue={store.slug} required placeholder="Slug" className="rounded-xl border border-white/10 bg-black/50 px-3 py-2 text-white outline-none" />
          <input name="category" defaultValue={store.category} required placeholder="Category" className="rounded-xl border border-white/10 bg-black/50 px-3 py-2 text-white outline-none" />
          <input name="logo" defaultValue={store.logo} placeholder="Logo URL" className="rounded-xl border border-white/10 bg-black/50 px-3 py-2 text-white outline-none" />
          <input name="website" defaultValue={store.website} placeholder="Website" className="rounded-xl border border-white/10 bg-black/50 px-3 py-2 text-white outline-none" />
          <input name="affiliate_link" defaultValue={store.affiliate_link} placeholder="Affiliate link" className="rounded-xl border border-white/10 bg-black/50 px-3 py-2 text-white outline-none" />
          <textarea name="description" defaultValue={store.description} placeholder="Description" className="md:col-span-2 rounded-xl border border-white/10 bg-black/50 px-3 py-2 text-white outline-none" />
          <label className="flex items-center gap-2 text-sm text-zinc-300"><input type="checkbox" name="featured" defaultChecked={Boolean(store.featured)} /> Featured</label>
          <select name="status" defaultValue={store.status} className="rounded-xl border border-white/10 bg-black/50 px-3 py-2 text-white outline-none">
            <option value="active">active</option>
            <option value="inactive">inactive</option>
          </select>
          <button type="submit" className="md:col-span-2 rounded-full bg-brand-gold px-4 py-2 font-medium text-black">Save changes</button>
        </form>
      </div>
    </main>
  );
}
