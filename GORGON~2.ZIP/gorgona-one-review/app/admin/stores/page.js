import Link from 'next/link';
import { requireAdmin } from '../../../lib/adminAuth';
import { getStores } from '../../../lib/mockData';
import { createStore, deleteStore } from '../actions';

export default async function AdminStoresPage() {
  await requireAdmin();
  const stores = await getStores();

  return (
    <main className="flex-1 py-10">
      <div className="rounded-3xl border border-brand-gold/20 bg-brand-gold/10 p-8 shadow-premium">
        <p className="text-sm uppercase tracking-[0.3em] text-brand-gold">Admin</p>
        <h1 className="mt-2 text-3xl font-semibold text-white">Manage stores</h1>
        <Link href="/admin" className="mt-4 inline-flex text-sm text-brand-gold">Back to dashboard</Link>
      </div>

      <div className="mt-8 rounded-2xl border border-white/10 bg-black/40 p-6">
        <h2 className="text-lg font-semibold text-white">Add a store</h2>
        <form action={createStore} className="mt-4 grid gap-3 md:grid-cols-2">
          <input name="name" required placeholder="Name" className="rounded-xl border border-white/10 bg-black/50 px-3 py-2 text-white outline-none" />
          <input name="slug" required placeholder="Slug" className="rounded-xl border border-white/10 bg-black/50 px-3 py-2 text-white outline-none" />
          <input name="category" required placeholder="Category" className="rounded-xl border border-white/10 bg-black/50 px-3 py-2 text-white outline-none" />
          <input name="logo" placeholder="Logo URL" className="rounded-xl border border-white/10 bg-black/50 px-3 py-2 text-white outline-none" />
          <input name="website" placeholder="Website" className="rounded-xl border border-white/10 bg-black/50 px-3 py-2 text-white outline-none" />
          <input name="affiliate_link" placeholder="Affiliate link" className="rounded-xl border border-white/10 bg-black/50 px-3 py-2 text-white outline-none" />
          <textarea name="description" placeholder="Description" className="md:col-span-2 rounded-xl border border-white/10 bg-black/50 px-3 py-2 text-white outline-none" />
          <label className="flex items-center gap-2 text-sm text-zinc-300"><input type="checkbox" name="featured" /> Featured</label>
          <select name="status" className="rounded-xl border border-white/10 bg-black/50 px-3 py-2 text-white outline-none">
            <option value="active">active</option>
            <option value="inactive">inactive</option>
          </select>
          <button type="submit" className="md:col-span-2 rounded-full bg-brand-gold px-4 py-2 font-medium text-black">Create store</button>
        </form>
      </div>

      <div className="mt-8 space-y-3">
        {stores.map((store) => (
          <div key={store.id} className="flex flex-wrap items-center justify-between gap-3 rounded-2xl border border-white/10 bg-black/40 p-4">
            <div>
              <p className="font-semibold text-white">{store.name} <span className="text-xs text-zinc-500">({store.slug})</span></p>
              <p className="text-sm text-zinc-400">{store.category} · {store.status}{store.featured ? ' · featured' : ''}</p>
            </div>
            <div className="flex items-center gap-3">
              <Link href={`/admin/stores/${store.id}/edit`} className="rounded-full border border-brand-gold/40 px-3 py-1 text-sm text-brand-gold">Edit</Link>
              <form action={deleteStore}>
                <input type="hidden" name="id" value={store.id} />
                <button type="submit" className="rounded-full border border-red-400/40 px-3 py-1 text-sm text-red-400">Delete</button>
              </form>
            </div>
          </div>
        ))}
      </div>
    </main>
  );
}
