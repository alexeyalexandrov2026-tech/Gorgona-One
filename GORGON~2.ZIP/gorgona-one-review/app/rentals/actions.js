'use server';

import { redirect } from 'next/navigation';
import { supabaseAdmin, supabaseAdminConfigured } from '../../lib/supabaseAdmin';

export async function submitReservation(formData) {
  const rentalSlug = formData.get('rentalSlug') || '';
  const name = formData.get('name') || '';
  const phone = formData.get('phone') || '';
  const email = formData.get('email') || '';
  const preferredDates = formData.get('preferredDates') || '';

  if (supabaseAdminConfigured) {
    await supabaseAdmin.from('rental_reservations').insert({
      rental_slug: rentalSlug,
      name,
      phone,
      email,
      preferred_dates: preferredDates
    });
  }

  redirect(`/rentals/${rentalSlug}?reserved=1`);
}
