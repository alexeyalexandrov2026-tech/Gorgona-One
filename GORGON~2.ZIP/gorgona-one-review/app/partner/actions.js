'use server';

import { redirect } from 'next/navigation';
import { supabaseAdmin, supabaseAdminConfigured } from '../../lib/supabaseAdmin';

export async function submitPartnerApplication(formData) {
  const businessName = formData.get('businessName') || '';
  const contactName = formData.get('contactName') || '';
  const email = formData.get('email') || '';
  const website = formData.get('website') || '';
  const message = formData.get('category') ? `Category: ${formData.get('category')}` : '';

  if (!businessName || !email) {
    redirect('/partner?status=error');
  }

  if (supabaseAdminConfigured) {
    const { error } = await supabaseAdmin.from('partner_submissions').insert({
      business_name: businessName,
      contact_name: contactName,
      email,
      website,
      message,
      status: 'pending'
    });
    if (error) {
      redirect('/partner?status=error');
    }
  }

  redirect('/partner?status=success');
}
