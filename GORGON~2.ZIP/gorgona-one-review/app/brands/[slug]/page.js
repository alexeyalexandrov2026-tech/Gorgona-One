import Link from 'next/link';
import { notFound } from 'next/navigation';
import { getStores, getStoreBySlug, getCouponsByStoreName } from '../../../lib/mockData';

export async function generateStaticParams() {
  const stores = await getStores();
  return stores.map((store) => ({ slug: store.slug }));
}

export default async function StoreProfilePage({ params }) {
  const store = await getStoreBySlug(params.slug);

  if (!store) {
    notFound();
  }

  const featuredCoupons = await getCouponsByStoreName(store.name);

  return (
    <main className="flex-1 py-10">
      <div className="rounded-3xl border border-white/10 bg-white/5 p-8 shadow-premium">
        <div className="flex flex-wrap items-center justify-between gap-4">
          <div>
            <p className="text-sm uppercase tracking-[0.3em] text-brand-gold">Store Profile</p>
            <h1 className="mt-2 text-3xl font-semibold text-white">{store.name}</h1>
            <p className="mt-3 max-w-2xl text-zinc-400">{store.description}</p>
          </div>
          <div className="rounded-2xl border border-brand-gold/20 bg-brand-gold/10 px-4 py-3">
            <p className="text-sm text-zinc-400">Category</p>
            <p className="font-semibold text-white">{store.category}</p>
          </div>
        </div>
        <div className="mt-8 grid gap-6 lg:grid-cols-[1fr_0.8fr]">
          <div className="rounded-2xl border border-white/10 bg-black/40 p-6">
            <p className="text-sm uppercase tracking-[0.3em] text-brand-gold">Active deals</p>
            <div className="mt-4 space-y-3">
              {featuredCoupons.slice(0, 3).map((coupon) => (
                <div key={coupon.id} className="rounded-2xl border border-white/10 bg-white/5 p-4">
                  <p className="font-semibold text-white">{coupon.discount}</p>
                  <p className="mt-2 text-sm text-zinc-400">{coupon.description}</p>
                </div>
              ))}
            </div>
          </div>
          <div className="rounded-2xl border border-white/10 bg-black/40 p-6">
            <p className="text-sm uppercase tracking-[0.3em] text-brand-gold">Affiliate</p>
            <Link href={store.affiliate_link} className="mt-4 inline-flex rounded-full bg-brand-gold px-4 py-2 font-medium text-black">Visit Affiliate Link</Link>
            <div className="mt-6 space-y-3 text-sm text-zinc-400">
              <p>Website: {store.website}</p>
              <p>Status: {store.status}</p>
              <p>Related offers: {featuredCoupons.length}</p>
            </div>
          </div>
    