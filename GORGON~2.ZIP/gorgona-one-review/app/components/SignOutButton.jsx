"use client";

import { useRouter } from 'next/navigation';
import { supabase, supabaseConfigured } from '../../lib/supabaseClient';

export function SignOutButton() {
  const router = useRouter();

  const handleSignOut = async () => {
    if (supabaseConfigured) {
      await supabase.auth.signOut();
    }
    router.push('/login');
    router.refresh();
  };

  return (
    <button onClick={handleSignOut} className="rounded-full border border-brand-gold/40 px-4 py-2 text-sm font-medium text-brand-gold transition hover:bg-brand-gold hover:text-black">
      Sign out
    </button>
  );
}
